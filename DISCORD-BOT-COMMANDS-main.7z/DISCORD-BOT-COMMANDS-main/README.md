# DISCORD-BOT-COMMANDS
This is a bot commands for u can use, please use credit to me
